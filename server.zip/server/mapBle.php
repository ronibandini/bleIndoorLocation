<?php

// script to update location from ble client

$fichero = 'ble.ini';

// open file
$myLocation = file_get_contents($fichero);

//echo "Actual state ".$actual;


?>
<center>
<img src="images/location<?=$myLocation?>.png" alt="Floor" align=center>
</center>
<center>
DfRobot BLE Beacons Indoor Positioning
<br>Developed by Roni Bandini, 2/2024, @RoniBandini
</center>
