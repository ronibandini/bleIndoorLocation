<?php
// BLE Beacon Indoor Positioning
// Script to update location from ble client
// Roni Bandini, Febr 2024

$fichero = 'ble.ini';

$actual=filter_var($_GET["location"], FILTER_SANITIZE_NUMBER_INT);

// write file
file_put_contents($fichero, $actual);

?>

<b>BLE Beacon Indoor Positioning</b>
<br>The location has been updated

